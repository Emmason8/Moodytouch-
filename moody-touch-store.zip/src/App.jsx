import React, { useState } from "react";
import { motion } from "framer-motion";

const products = [
  { id: 1, name: "Luxury Wristwatch", price: 25000, image: "https://via.placeholder.com/300" },
  { id: 2, name: "Designer Perfume", price: 18000, image: "https://via.placeholder.com/300" },
  { id: 3, name: "Stylish Sunglasses", price: 12000, image: "https://via.placeholder.com/300" },
];

export default function App() {
  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (id) => {
    setCart((prev) => prev.filter((item) => item.id !== id));
  };

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handlePayment = () => {
    const handler = window.PaystackPop.setup({
      key: "YOUR_PUBLIC_KEY_HERE",
      email: "customer@email.com",
      amount: total * 100,
      currency: "NGN",
      callback: function (response) {
        alert("Payment successful! Ref: " + response.reference);
        setCart([]);
      },
      onClose: function () {
        alert("Payment cancelled");
      },
    });

    handler.openIframe();
  };

  return (
    <div style={{ background: "black", color: "white", minHeight: "100vh", padding: "20px" }}>
      <h1 style={{ textAlign: "center", fontSize: "40px" }}>Moody Touch</h1>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px,1fr))", gap: "20px", marginTop: "40px" }}>
        {products.map((product) => (
          <motion.div key={product.id} whileHover={{ scale: 1.05 }} style={{ background: "#111", padding: "15px", borderRadius: "10px" }}>
            <img src={product.image} style={{ width: "100%" }} />
            <h3>{product.name}</h3>
            <p>₦{product.price}</p>
            <button onClick={() => addToCart(product)}>Add to Cart</button>
          </motion.div>
        ))}
      </div>

      <div style={{ background: "white", color: "black", marginTop: "40px", padding: "20px", borderRadius: "10px" }}>
        <h2>Cart</h2>
        {cart.map((item) => (
          <div key={item.id}>
            {item.name} x {item.quantity}
            <button onClick={() => removeFromCart(item.id)}>Remove</button>
          </div>
        ))}
        <h3>Total: ₦{total}</h3>
        <button onClick={handlePayment}>Pay Now</button>
      </div>
    </div>
  );
}